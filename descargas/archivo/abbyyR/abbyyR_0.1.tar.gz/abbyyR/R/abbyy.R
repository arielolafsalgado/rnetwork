#' \pkg{abbyyR} makes OCR easy.
#'
#' @name abbyyR
#' @docType package
NULL
