library(testthat)
library(ActivityIndex)

test_check("ActivityIndex")
