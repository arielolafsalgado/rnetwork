# ActivityIndex 0.3.6

* Example for `computeActivityIndex` added, taken from vignette.
* `print` methods for S3 `ActivityIndex` object created.

# ActivityIndex 0.3.5

* Vignette now in Markdown.
* Site is built using `pkgdown::build_site`.
* CRAN release version.

# ActivityIndex 0.3.4

* Adding tests with `testthat`.
* Added conversions to `data.table` when necessary.  
* Fixing docs with `\code` accidentally in there.

# ActivityIndex 0.3.3

* Added a `NEWS.md` file to track changes to the package.
