#' Case Based Reasoning
#' @docType package
#' @name CaseBasedReasoning
#' @import R6
#' @importFrom RcppParallel RcppParallelLibs
#' @import data.table
#' @useDynLib CaseBasedReasoning, .registration = TRUE
NULL
