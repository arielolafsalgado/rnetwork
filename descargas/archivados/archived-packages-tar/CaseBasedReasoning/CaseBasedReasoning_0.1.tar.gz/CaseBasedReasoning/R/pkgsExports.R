#' @importFrom magrittr %>%
#' @importFrom stats ar
#' @importFrom stats as.formula
#' @importFrom stats na.omit
#' @importFrom data.table :=


#' @export
magrittr::`%>%`