library(testthat)
library(BifactorIndicesCalculator)

test_check("BifactorIndicesCalculator")
