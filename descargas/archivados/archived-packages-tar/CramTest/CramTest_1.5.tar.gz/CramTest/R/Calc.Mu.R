Calc.Mu <-
function(mu, xi, sigma, mean){
  return(mu + sigma/(1-xi)-mean)
}
