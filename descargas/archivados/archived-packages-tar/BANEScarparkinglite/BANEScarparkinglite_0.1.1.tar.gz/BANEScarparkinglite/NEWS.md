BANEScarparkinglite v0.1.1 (Release date: 2018-01-20)
=====================================================

Additions:

* `get_daily_weather` now creates a weather table for any given date range (no longer limited to retrieving 398 records in one go...) and the format of this table is nicer than before (better column names etc.)
* Added code tests for all main functionality (and added `covr` reporting to Travis)
* Added NEWS file to keep track of changes

Bugfixes:

* Minor usability improvements for several functions





BANEScarparkinglite v0.1.0 (Release date: 2017-08-27)
=====================================================

Additions:

* Initial release; all functionality of main BANEScarparking package, without the attached datasets
* Travis CI is being used to check the build
