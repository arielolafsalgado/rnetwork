library(testthat)
library(BANEScarparkinglite)

test_check("BANEScarparkinglite")