plot.trmatplot <- function(x, ...) {

	plot(x$plot, ...)

}
