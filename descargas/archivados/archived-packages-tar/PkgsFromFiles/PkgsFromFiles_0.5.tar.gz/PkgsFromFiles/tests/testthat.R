library(testthat)
library(PkgsFromFiles)

test_check("PkgsFromFiles")
