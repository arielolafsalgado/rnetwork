# DEvis 1.0.1 - December 7, 2018

* Added LFC filtering parameter to de_counts().
* Fixed a bug where MDS_hulls() used only union based aggregation when setting DEOnly=TRUE, regardless of aggregation method.
* Fixed a bug in MDS_hulls() where exclusion of specified data didn't work with certain metadata column name formats.
* Changed vignette to HTML format to prevent issues with LaTeX output rendering.

# October 17, 2018

DEvis is now available through the CRAN repository. 

# DEvis 1.0.0

Initial release.  
