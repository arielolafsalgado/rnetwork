library(testthat)
library(KRIG)

test_check("KRIG")
