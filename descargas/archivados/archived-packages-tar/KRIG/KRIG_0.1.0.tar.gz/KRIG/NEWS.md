# KRIG 0.1.0

* First release
* Including vignettes with Kriging examples
