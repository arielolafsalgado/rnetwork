.onLoad <- function(lib, pkg) {

  library.dynam("PSM", pkg, lib)
}
