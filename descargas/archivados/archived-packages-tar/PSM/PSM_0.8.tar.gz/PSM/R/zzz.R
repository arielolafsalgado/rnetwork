.First.lib <- function(lib, pkg) {

  library.dynam("PSM", pkg, lib)
}
