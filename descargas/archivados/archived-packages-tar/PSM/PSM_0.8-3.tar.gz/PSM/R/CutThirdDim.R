`CutThirdDim` <-
function(a) {
  dim(a) <- dim(a)[1:2]
  a
}

