# CDECRetrieve 0.1.2

* update code to reflect recent changes on CDEC.gov, namely use the SHEF endpoint for `cdec_datasets()`.

# CDECRetrieve 0.1.1 

* `cdec_query` now correctly does not force strings as factors.
* `cdec_query` uses a tibble rather than a `data.frame()`
* use of the `glue` package has been added most notably in `cdec_query`
* overall code refactor to make easier to read 

# CDECRetrieve 0.1.0

* Version available through CRAN
* Added a `NEWS.md` file to track changes to the package.

