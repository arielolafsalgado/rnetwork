library(testthat)
library(INDperform)

test_check("INDperform")
