#' BreedingSchemeLanguage
#' 
#' Describe and simulate breeding schemes
#' 
#' @name BreedingSchemeLanguage
#' @docType package
#' @useDynLib BreedingSchemeLanguage
#' @importFrom Rcpp sourceCpp
#' @importFrom snowfall sfLapply sfInit sfStop
