#' BreedingSchemeLanguage
#' 
#' Describe and simulate breeding schemes
#' 
#' @name BreedingSchemeLanguage
#' @docType package
#' @import ggplot2 lme4 snowfall Rcpp 
#' @useDynLib BreedingSchemeLanguage
#' @importFrom Rcpp sourceCpp
library(Rcpp)
