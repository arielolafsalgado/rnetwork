# function odd in gtools
odd<-function (x) 
  x%%2 == 1
