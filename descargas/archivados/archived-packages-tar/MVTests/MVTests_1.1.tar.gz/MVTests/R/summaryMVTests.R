#' @title Summarizing Results in MVTests Package
#'
#' @description
#' \code{summary.MVTests} function summarizes of results of functions in this
#'  package.
#'
#' @details
#' This function prints a summary of the results of multivariate hypothesis 
#' tests in the \code{MVTests} package.
#' 
#' @importFrom stats cor cov pchisq pf pnorm qchisq qf shapiro.test var
#' @param object an object of class \code{MVTests}. 
#' @param ... additional parameters.
#' @method summary MVTests
#' @export
#' @return the input object is returned silently.
#' @author Hasan BULUT <hasan.bulut@omu.edu.tr>
#' @examples
#' 
#' # One Sample Hotelling T Square Test
#' data(iris)
#' X<-iris[1:50,1:4]
#' mean0<-c(6,3,1,0.25)
#' result.onesample <- OneSampleHT2(data=X,mu0=mean0,alpha=0.05)
#' summary(result.onesample)
#' 
#' #Two Independent Sample Hotelling T Square Test
#' data(iris)
#' G<-c(rep(1,50),rep(2,50))
#' result.twosamples <- TwoSamplesHT2(data=iris[1:100,1:4],group=G,alpha=0.05)
#' summary(result.twosamples)
#'
#'  #One Way MANOVA
#' data(iris)
#' results.Wilks <- Manova(data=iris[,1:4],group=iris[,5],alpha=0.05)
#' summary(results.Wilks)
#' 
#' #Box's M Test
#' data(iris)
#' result.BoxM <- BoxM(data=iris[,1:4],group=iris[,5])
#' summary(result.BoxM)
#' 
#' #Barlett's Test of Sphericity
#' data(iris)
#' result.Bsper <- Bsper(data=iris[,1:4])
#' summary(result.Bsper)
#'
#' #Multivariate Shapio-Wilk Test
#' data(iris)
#' result.mvShapiro <- mvShapiro(data=iris[,1:4])
#' summary(result.mvShapiro)
#' result.mvShapiro.group <- mvShapiro(data=iris[,1:4],group=TRUE,G=iris[,5])
#' summary(result.mvShapiro.group)
#'
#' #Bartlett's Test for One Sample Covariance Matrix
#' data(iris) 
#' S<-matrix(c(5.71,-0.8,-0.6,-0.5,-0.8,4.09,-0.74,-0.54,-0.6,-0.74,
#'           7.38,-0.18,-0.5,-0.54,-0.18,8.33),ncol=4,nrow=4)
#' result.bcov<- Bcov(data=iris[,1:4],Sigma=S)
#' summary(result.bcov)


summary.MVTests<-function(object,...){
 
if (!inherits(object,"MVTests"))
	stop("Object must be of class 'MVTests'")

###### One Sample Hotelling T Square Test
if (object$Test=="OneSampleHT2") {  

cat("       One Sample Hotelling T Square Test","\n\n")
cat("Hotelling T Sqaure Statistic =",object$HT2,"\n",
"F value =",round(object$F,3),
", df1 =",object$df[1],", df2 =",object$df[2],", p-value:",format.pval(object$p.value,digits = 3),"\n\n")

cat("   	              Descriptive Statistics\n\n")
print(object$Descriptive)
cat("\n\n")
cat("  	            Detection important variable(s)\n\n")
print(object$CI)
}

####### Two Independent Samples Hotelling T Square Test
if (object$Test=="TwoSamplesHT2") {  

cat("              Two Independent Samples Hotelling T Square Test","\n\n")
cat("Hotelling T Sqaure Statistic =",object$HT2,"\n",
"F value =",round(object$F,3),
", df1 =",object$df[1],", df2 =",object$df[2],", p-value:",format.pval(object$p.value,digits = 3),"\n\n")

cat("   	       Descriptive Statistics (The First Group) \n\n")
print(object$Descriptive1)
cat("\n\n")

cat("   	       Descriptive Statistics (The Second Group) \n\n")
print(object$Descriptive2)
cat("\n\n")

cat("  	       Detection important variable(s)\n\n")
print(object$CI)
}

####### Box-M Test
if (object$Test=="BoxM") {  

cat("       Box's M Test","\n\n")
cat("Chi-Squared Value =",object$Chisq,", df =",object$df," and p-value:",format.pval(object$p.value,digits = 3),"\n\n")
}

####### Bartlett's Sphericity Test
if (object$Test=="Bsper") {  

cat("       Bartlett's Sphericity Test","\n\n")
cat("Chi-Squared Value =",object$Chisq,", df =",object$df," and p-value:",format.pval(object$p.value,digits = 3),"\n\n")
cat("       Correlation Matrix","\n\n")
print(object$R)

}

 ####### MANOVA
if (object$Test=="MANOVA") {  

	if (object$Homogeneity=="TRUE") {
 
cat("       One Way Multivariate Analysis of Variance","\n\n")
cat("Method :",object$Method,"\n")
cat("The Value of Test Statistic =",object$Test.Stat,"\n",
"F value =",round(object$App.Stat,3),
", df1 =",object$df[1],", df2 =",object$df[2],", p-value:",format.pval(object$p.value,digits = 3),"\n\n")

cat("   	Descriptive Statistics\n")
print(object$Descriptive)
cat("\n\n")


cat("   Detection important variable(s)\n")
if (object$Method!="Roy"){
print(" Confidence Intervals are calculated only in the Roy Method.")
} else if (object$CI=="FALSE"){
print(" To calculate confidence intervals, it must be CI=TRUE.")
} else {
print(object$Decision.Matrices)
}} 

if (object$Homogeneity=="FALSE") {
 
cat("       One Way Multivariate Analysis of Variance","\n\n")
cat("     (The Covariance Matrices are not homogeneity!)","\n\n")
cat("Method :",object$Method,"\n")
cat("The Value of Test Statistic =",object$Test.Stat,"\n",
"Chi-Squared value =",round(object$App.Stat,3),
"df =",object$df,", p-value:",format.pval(object$p.value,digits = 3),"\n\n")

cat("   	Descriptive Statistics\n")
print(object$Descriptive)
cat("\n\n")
}

}  #MANOVA Final






 ####### Multivariate Shapiro-Wilk Test 
if (object$Test=="mvShapiro") {

     if(object$group=="FALSE") {  

cat("       Multivariate Shapiro Wilk Test for Normality","\n\n")
cat("The Value of Test Statistic =",object$Stat,"\n",
"p-value:",format.pval(object$p.value,digits = 3),"\n\n")

     }
       
     if (object$group=="TRUE") {  

cat("       Multivariate Shapiro Wilk Test for Normality with Grouped Data","\n\n")
cat("       The Value of Test Statistic and The P-Values:","\n\n")
Result<-cbind(object$Stat,object$p.value[,2])
colnames(Result)<-c("Groups","Statistics","p-values")
print(Result)

     }
 }

## Bartlett's Test for one covariance matrices 
if (object$Test=="Bcov") {  

cat("       Bartlett's Test for One Sample Covariance Matrix","\n\n")
cat("Chi-Squared Value =",object$Chisq,", df =",object$df," and p-value:",format.pval(object$p.value,digits = 3),"\n\n")
}

## Multivariate Paired Test 
if (object$Test=="Mpaired") {  

cat("       Multivariate Paired Hotelling T Square Test","\n\n")
cat("Hotelling T Sqaure Statistic =",object$HT2,"\n",
"F value =",round(object$F,3),
", df1 =",object$df[1],", df2 =",object$df[2],", p-value:",format.pval(object$p.value,digits = 3),"\n\n")

cat("   	       Descriptive Statistics (The First Treatment) \n\n")
print(object$Descriptive1)
cat("\n\n")

cat("   	       Descriptive Statistics (The Second Treatment) \n\n")
print(object$Descriptive2)
cat("\n\n")

cat("   	       Descriptive Statistics (The Differences) \n\n")
print(object$Descriptive.Difference)
cat("\n\n")

}



}  # Finish summary Function

