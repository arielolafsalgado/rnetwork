#' @import seqHMM
#' @import TraMineR
#' @import ggplot2
#' @importFrom reshape2 melt
#' @importFrom stats logLik
NULL
