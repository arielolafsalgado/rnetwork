# GADGET 0.2.0

* Removed S3 object approach to experiment
* Split Sequential and Static design methods
* Parallel evaluation of design criteria added
* Added a `NEWS.md` file to track changes to the package.

# GADGET 0.1.0

* Prototype version
* S3 object based approach to experiment

