library(testthat)
library(GADGET)

test_check("GADGET")
