library(testthat)
library(EMSHS)

test_check("EMSHS")
