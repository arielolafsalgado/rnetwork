/*
 * utils.cpp
 *
 *  Created on: Apr 26, 2019
 */

int VERBOSE_LEVEL = 0;


