# PowerfulMaxEigenpair
An implementation for using a fast and powerful algorithm to compute the
maximal eigenpair of the tridiagonal matrices in R. It provides one algorithm and two auxiliary functions to acheive it.
