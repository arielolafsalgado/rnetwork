The .csv file needs to have two columns. The first column will be interpreted as the times, and the second as the magnitudes. 
