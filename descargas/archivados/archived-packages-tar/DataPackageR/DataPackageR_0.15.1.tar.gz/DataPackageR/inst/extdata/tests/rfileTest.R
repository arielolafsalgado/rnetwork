#' ---
#' title: Sample report  from R script
#' author: Greg Finak
#' date: August 1, 2018
#' ---
data <- runif(100)
