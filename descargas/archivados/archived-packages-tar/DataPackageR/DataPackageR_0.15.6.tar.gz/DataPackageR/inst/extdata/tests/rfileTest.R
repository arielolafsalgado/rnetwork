#' ---
#' title: Sample report  from R script
#' author: Greg Finak
#' date: August 1, 2018
#' output: pdf_document
#' ---
data <- runif(100)
