# 0.5.0

* Added a `NEWS.md` file to track changes to the package.

# 0.4.5

* Add the chatbox function. This is useful for more complex chatbots that use contexts.
