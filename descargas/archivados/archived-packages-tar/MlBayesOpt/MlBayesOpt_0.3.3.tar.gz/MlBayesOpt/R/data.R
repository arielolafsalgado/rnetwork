#'  Odd-numbered rows of iris data
#'
#'  Odd-numbered rows of iris data
#'
"iris_train"

#'  Even-numbered rows of iris data
#'
#'  Even-numbered rows of iris data
#'
"iris_test"

#' Reproduced from fashion-mnist data
#'
#' Reproduced from fashion-mnist data
#'
#' @source \url{https://github.com/ymattu/fashion-mnist-csv}
#'
"fashion_train"

#' Reproduced from fashion-mnist data
#'
#' Reproduced from fashion-mnist data
#'
#' @source \url{https://github.com/ymattu/fashion-mnist-csv}
#'
"fashion_test"

#' Reproduced from fashion-mnist data
#'
#' Reproduced from fashion-mnist data
#'
#' @source \url{https://github.com/ymattu/fashion-mnist-csv}
#'
"fashion"
