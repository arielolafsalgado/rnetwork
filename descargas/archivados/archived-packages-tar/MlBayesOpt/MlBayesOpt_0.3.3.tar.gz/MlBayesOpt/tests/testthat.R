library(testthat)
library(MlBayesOpt)

test_check("MlBayesOpt")
