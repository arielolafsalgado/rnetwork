# CoreGx v0.1.1

## Bug Fixes
- Changed `class(x) == 'matrix'` to `is.matrix(x)` to prevent breaking backwards compatibility for R-devel.
