library(testthat)
library(CaliCo)

test_check("CaliCo")


