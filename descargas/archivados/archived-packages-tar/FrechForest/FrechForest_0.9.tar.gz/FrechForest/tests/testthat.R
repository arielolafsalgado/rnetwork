library(testthat)
library(FrechForest)

test_check("FrechForest")
