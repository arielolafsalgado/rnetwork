## HMMoce 1.0.0
This is a new package. The stable release during October 2017 is called version 1.0.0