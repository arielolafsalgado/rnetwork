#' NeuralSens: Sensibility analysis to NeuralNets
#'
#' Visualization and analysis tools to aid in the interpretation of
#' neural network models.
#'
#' @name NeuralSens
#' @docType package
NULL
