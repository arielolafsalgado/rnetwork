biomassVector <- function(limfile)
{
  message("Biomass vector list created")
  return(limfile$Components$val)

}
