library(testthat)
library(GetITRData)

test_check("GetITRData")
