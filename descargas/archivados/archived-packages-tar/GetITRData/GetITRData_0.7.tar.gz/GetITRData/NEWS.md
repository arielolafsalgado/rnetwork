### Version 0.7 (2018-02-28)

- fixed bug in vignette

### Version 0.6 (2017-10-21)

- fixed bug with NA dates and names of companies
- Implemented inflation adjusted values
- Added current capital composition
- added tickers list for each company
- Dividends history is now available
- Yearly data (DFP system) is now also available
- Users can now select max levels in account description (rows)

### Version 0.5 (2017-09-29)

First version.
