# MachineLearning 0.1.3
* Fix several issues of help files and S3 functions
* Fix consistence of MLA S3methods 
* New indepedent function for CART plot with compatibility with Rpart plots (Unstable version)
* New autotest for several functions
* Refix CART function plot & summary method
* Update Exports

# MachineLearning 0.0.3
* Fix a bug in CART function

# MachineLearning 0.0.2
* Correct CRAN errors

# MachineLearning 0.0.1
* Initial CRAN release
* Added a `NEWS.md` file to track changes to the package.
