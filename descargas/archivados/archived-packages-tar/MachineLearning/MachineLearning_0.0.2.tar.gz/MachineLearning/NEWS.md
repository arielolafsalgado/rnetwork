# MachineLearning 0.0.2
* Correct CRAN errors

# MachineLearning 0.0.1
* Initial CRAN release
* Added a `NEWS.md` file to track changes to the package.
