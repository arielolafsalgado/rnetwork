library(testthat)
library(MachineLearning)

test_check("MachineLearning")
