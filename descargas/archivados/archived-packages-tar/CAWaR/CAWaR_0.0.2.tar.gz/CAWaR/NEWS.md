=================================================================================

#### CAWaR 0.0.2

=================================================================================

### Fixes
* Update access to spatial objects in accordance with the latest Proj4 update 
* Removed spatialEco package dependency (affected by Proj4 update)

=================================================================================

#### CAWaR 0.0.1

=================================================================================

### Initial release to CRAN with the following functions:
  * splitSamples()
  * segmentRaster()
  * phenoCropVal()
  * PhenoCropClass()
  * meStack()
  * matchIndices()
  * findBare()
  * extractTS()
  * extract2()
  * countCropCycles()
  * compareLabel()
  * checkSamples()
  * analyzeTS()




