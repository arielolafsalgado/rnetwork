=================================================================================

#### CAWaR 0.1.0

=================================================================================

### Initial release to CRAN with the following functions:
  * splitSamples()
  * segmentRaster()
  * phenoCropVal()
  * PhenoCropClass()
  * meStack()
  * matchIndices()
  * findBare()
  * extractTS()
  * extract2()
  * countCropCycles()
  * compareLabel()
  * checkSamples()
  * analyzeTS()




