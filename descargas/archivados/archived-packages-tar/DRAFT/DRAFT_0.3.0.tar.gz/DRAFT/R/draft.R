# This file provides extra details for the package man page

#' @details 
 
#' The primary function that a user will need is runDRAFT().  See \code{\link{runDRAFT}} for more details.  Also, see the vignette \code{vignette("DRAFT_examples")} for some examples.
#'   
#' @keywords internal
#' @useDynLib DRAFT, .registration = TRUE
"_PACKAGE"
#> [1] "_PACKAGE"

