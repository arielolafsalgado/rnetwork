[![CRAN status](http://www.r-pkg.org/badges/version/Miso)](https://cran.r-project.org/package=Miso) 
[![CRAN downloads](http://cranlogs.r-pkg.org/badges/grand-total/Miso)](https://cran.r-project.org/package=Miso)

Miso: Multi-Isotope Labeling for Metabolomics Analysis

Version: 0.1.3

## Description

- An efficient approach for fishing out the dual or multiple isotope labeling assisted metabolomics data analytes


## Usage

Please refer to [Miso_example](https://github.com/YonghuiDong/Miso_example) for a step-by-step usage guide.
