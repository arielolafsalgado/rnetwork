.onAttach <- function(...) {
  packageStartupMessage("Welcome to DALEX2 (version: ", utils::packageVersion("DALEX2"), ").")
}
