library(testthat)
library(DALEX2)

test_check("DALEX2")
