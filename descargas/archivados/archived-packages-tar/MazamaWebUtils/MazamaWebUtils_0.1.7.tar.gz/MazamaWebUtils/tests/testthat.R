library(testthat)
library(MazamaWebUtils)

test_check("MazamaWebUtils")
