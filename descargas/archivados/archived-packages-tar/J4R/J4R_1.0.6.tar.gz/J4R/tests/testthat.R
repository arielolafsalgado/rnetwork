library(testthat)
library(J4R)

test_check("J4R")
