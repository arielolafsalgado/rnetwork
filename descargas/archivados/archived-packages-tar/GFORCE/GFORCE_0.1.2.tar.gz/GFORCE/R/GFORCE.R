# Package level documentation






# FOR TESTS -- LOADS C SYMBOLS TO USE WITH TESTTHAT
#' @useDynLib GFORCE kmeans_dual_solution_primal_min_R
#' @useDynLib GFORCE kmeans_pp_R
#' @useDynLib GFORCE test_daps
#' @useDynLib GFORCE test_dsmtd
#' @useDynLib GFORCE test_dvexp
#' @useDynLib GFORCE test_dsumv
#' @useDynLib GFORCE test_dtrace
#' @useDynLib GFORCE test_dcsum
#' @useDynLib GFORCE test_dxpyez
#' @useDynLib GFORCE test_clust_to_opt_val
#' @useDynLib GFORCE test_smoothed_objective
#' @useDynLib GFORCE test_project_E
#' @useDynLib GFORCE test_project_C_perpendicular
#' @useDynLib GFORCE test_project_C_perpendicular_nok
#' @useDynLib GFORCE test_smoothed_gradient
#' @useDynLib GFORCE test_smoothed_gradient_X_base
#' @useDynLib GFORCE test_smoothed_gradient_S_base
dummy_load_function <- function(){;}