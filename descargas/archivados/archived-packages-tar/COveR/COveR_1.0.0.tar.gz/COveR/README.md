# COveR

Clustering with Overlaps in R.
