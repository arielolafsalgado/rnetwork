library(testthat)
library(COveR)

test_check("COveR")
