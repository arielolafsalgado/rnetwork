#' Image data Lena
#'
#' Lena is a benchmark testing image for image processing. The 512 by 512 matrix
#' is created by reading in the png formed image.
#'
#' @format A 512 by 512 matrix
"lena"

#' Image data Lena_crop
#'
#' Cropped from Image Lena.
#'
#' @format A 100 by 100 matrix
"lena_crop"
