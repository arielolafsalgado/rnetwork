## version 1.0.0
### The first version of the package
---

## version 1.1.0
- Bug fixes and well defined result
- Function FreqMet added
- A software paper associated with this package MetabolicSurv will be available in few weeks.

---

### setup

- added NEWS.md creation

