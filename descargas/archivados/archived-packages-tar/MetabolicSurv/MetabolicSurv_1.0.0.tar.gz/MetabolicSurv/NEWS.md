## version 1.0.0

---


### The first version of the package

- A software paper associated with this package MetabolicSurv will be available in few weeks.



## version 0.0.0.9000

---

### setup

- added NEWS.md creation

