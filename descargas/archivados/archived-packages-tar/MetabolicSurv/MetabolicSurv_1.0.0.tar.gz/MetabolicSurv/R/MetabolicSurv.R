#' MetabolicSurv: A biomarker validation approach for predicting survival using metabolic signature.
#'
#' This package develope biomarker signature for metabolic data. It contains a set of functions and cross validation methods  to validate and select biomarkers when the outcome of interest is survival. The package can handle prognostic factors and mainly metabolite matrix as input, the package can served as biomarker validation tool.
#'
#' @section MetabolicSurv functions:
#' \enumerate{
#' \item It can be used with any form of high dimensional/omics data such as: Metabolic data, Gene expression matrix, incase you dont have a data it can simulate hypothetical scinerio of a high dimensional data based on the desired biological parameters
#' \item It developed any form of signature from the high dimensional data to be used for other purpose
#' \item It also employs data reduction techniques such as PCA, PLS and Lasso
#' \item It classifies subjects based on the signatures into Low and high risk group
#' \item It incorporate the use of subject prognostic information for the to enhance the biomarker for classification
#' \item It gives information about the surival rate of subjects depending on the classification
#' }
#'
#' @author Olajumoke Evangelina Owokotomo, \email{olajumoke.owokotomo@@uhasselt.be}
#' @author Ziv Shkedy
#' @docType package
#' @name MetabolicSurv
NULL
